SimpleLockpicking Resourcepack by ShermansWorld - VERSION 1.0 - 4/5/2025

Resource pack includes:
- lockpick texture
- lockpick model

This is an optional resource pack add-on to the SimpleLockpicking plugin, authored by ShermansWorld and licensed under the MIT License.
You do not need to request permission to modify this resource pack, or include its contents in any other resource packs.
